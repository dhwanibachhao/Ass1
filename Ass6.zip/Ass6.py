import tkinter as tk
from tkinter import messagebox

# Function to update expression
def press(key):
    entry_text.set(entry_text.get() + str(key))

# Function to clear input
def clear():
    entry_text.set("")

# Function to calculate result
def calculate():
    try:
        result = eval(entry_text.get())
        entry_text.set(result)
    except ZeroDivisionError:
        messagebox.showerror("Error", "Division by zero is not allowed")
        entry_text.set("")
    except:
        messagebox.showerror("Error", "Invalid Input")
        entry_text.set("")

# Main window
root = tk.Tk()
root.title("Calculator")
root.geometry("300x400")
root.resizable(False, False)

entry_text = tk.StringVar()

# Entry box
entry = tk.Entry(root, textvariable=entry_text, font=("Arial", 18), bd=5, relief=tk.RIDGE, justify="right")
entry.pack(fill="x", padx=10, pady=10)

# Button frame
frame = tk.Frame(root)
frame.pack()

buttons = [
    ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
    ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
    ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
    ('0', 4, 0), ('.', 4, 1), ('+', 4, 2), ('=', 4, 3),
]

# Create buttons
for (text, row, col) in buttons:
    if text == "=":
        btn = tk.Button(frame, text=text, width=5, height=2, font=("Arial", 14),
                        command=calculate)
    else:
        btn = tk.Button(frame, text=text, width=5, height=2, font=("Arial", 14),
                        command=lambda t=text: press(t))
    btn.grid(row=row, column=col, padx=5, pady=5)

# Clear button
clear_btn = tk.Button(root, text="Clear", width=20, height=2, font=("Arial", 14),
                      bg="red", fg="white", command=clear)
clear_btn.pack(pady=10)

root.mainloop()
